<?xml version="1.0" encoding="ISO-8859-1"?>
<!--Parcela Catastral de la D.G. del Catastro.-->
<!--La precisión es la que corresponde nominalmente a la escala de captura de la cartografía-->
<FeatureCollection xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:gml="http://www.opengis.net/gml/3.2" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:cp="http://inspire.ec.europa.eu/schemas/cp/4.0" xmlns:gmd="http://www.isotc211.org/2005/gmd" xsi:schemaLocation="http://www.opengis.net/wfs/2.0 http://schemas.opengis.net/wfs/2.0/wfs.xsd http://inspire.ec.europa.eu/schemas/cp/4.0 http://inspire.ec.europa.eu/schemas/cp/4.0/CadastralParcels.xsd" xmlns="http://www.opengis.net/wfs/2.0" timeStamp="2026-11-14T07:20:55" numberMatched="112" numberReturned="112">
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0427610DF3802G">
      <cp:areaValue uom="m2">260</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0427610DF3802G" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0427610DF3802G.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="16">430441.32 4582602.54 430451.5 4582592.11 430447.17 4582587.95 430445.9 4582586.73 430442.67 4582583.62 430440.09 4582581.14 430438.58 4582579.7 430428.47 4582590.08 430429.97 4582591.53 430430.77 4582592.31 430432.61 4582594.09 430434.36 4582595.79 430434.74 4582596.16 430437.82 4582599.14 430439.07 4582600.35 430441.32 4582602.54</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0427610DF3802G</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>10</cp:label>
      <cp:nationalCadastralReference>0427610DF3802G</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0427610DF3802G" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430441.04 4582592.53</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0427611DF3802G">
      <cp:areaValue uom="m2">125</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0427611DF3802G" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0427611DF3802G.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="14">430451.5 4582592.11 430456.35 4582587.12 430452.16 4582583.07 430451.18 4582582.12 430449.53 4582580.52 430447.86 4582578.91 430444.97 4582576.12 430443.47 4582574.67 430438.58 4582579.7 430440.09 4582581.14 430442.67 4582583.62 430445.9 4582586.73 430447.17 4582587.95 430451.5 4582592.11</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0427611DF3802G</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>11</cp:label>
      <cp:nationalCadastralReference>0427611DF3802G</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0427611DF3802G" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430448.58 4582584.47</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0427612DF3802G">
      <cp:areaValue uom="m2">262</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0427612DF3802G" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0427612DF3802G.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="16">430456.35 4582587.12 430467.15 4582575.98 430462 4582571.88 430457.63 4582568.43 430455.67 4582566.88 430454.69 4582566.11 430453.06 4582564.82 430452.53 4582565.36 430447.05 4582570.99 430443.47 4582574.67 430444.97 4582576.12 430447.86 4582578.91 430449.53 4582580.52 430451.18 4582582.12 430452.16 4582583.07 430456.35 4582587.12</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0427612DF3802G</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>12</cp:label>
      <cp:nationalCadastralReference>0427612DF3802G</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0427612DF3802G" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430456.04 4582577.35</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0427613DF3802G">
      <cp:areaValue uom="m2">270</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0427613DF3802G" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0427613DF3802G.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="19">430453.06 4582564.82 430454.69 4582566.11 430455.67 4582566.88 430457.63 4582568.43 430462 4582571.88 430467.15 4582575.98 430471.08 4582571.93 430470.88 4582552.05 430467.98 4582549.53 430466.33 4582551.23 430465.06 4582552.53 430462.35 4582555.31 430462.15 4582555.52 430460.28 4582557.43 430457.72 4582560.04 430457.45 4582560.32 430456.12 4582561.68 430455.51 4582562.3 430453.06 4582564.82</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0427613DF3802G</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>13</cp:label>
      <cp:nationalCadastralReference>0427613DF3802G</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0427613DF3802G" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430462.24 4582564.39</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0427614DF3802G">
      <cp:areaValue uom="m2">1577</cp:areaValue>
      <cp:beginLifespanVersion>2019-01-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0427614DF3802G" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0427614DF3802G.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="40">430417.98 4582579.92 430420.54 4582582.4 430422.72 4582584.51 430424.25 4582585.99 430426.18 4582587.86 430428.47 4582590.08 430438.58 4582579.7 430443.47 4582574.67 430447.05 4582570.99 430452.53 4582565.36 430453.06 4582564.82 430455.51 4582562.3 430456.12 4582561.68 430457.45 4582560.32 430457.72 4582560.04 430460.28 4582557.43 430462.15 4582555.52 430462.35 4582555.31 430465.06 4582552.53 430466.33 4582551.23 430467.98 4582549.53 430464.02 4582545.65 430448.07 4582530.03 430446.38 4582531.77 430445.9 4582532.27 430445.05 4582533.15 430444.13 4582534.1 430442.19 4582536.09 430441.82 4582536.47 430437.72 4582540.69 430436.11 4582542.35 430435.79 4582542.68 430432.9 4582545.65 430432.58 4582545.98 430429.98 4582548.65 430427.04 4582551.68 430408.55 4582570.7 430415.43 4582577.43 430415.58 4582577.57 430417.98 4582579.92</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0427614DF3802G</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>14</cp:label>
      <cp:nationalCadastralReference>0427614DF3802G</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0427614DF3802G" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430438.27 4582558.58</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0526601DF3802F">
      <cp:areaValue uom="m2">221</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0526601DF3802F" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0526601DF3802F.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="17">430508.27 4582533.77 430506.42 4582531.95 430504 4582529.57 430501.83 4582527.43 430501.19 4582526.81 430500.53 4582526.16 430498.21 4582523.88 430496.09 4582521.8 430492.18 4582526.18 430491.08 4582527.41 430489.1 4582529.63 430488.2 4582530.64 430485.51 4582533.67 430483.21 4582536.26 430484.67 4582537.69 430504.71 4582537.43 430508.27 4582533.77</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0526601DF3802F</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>01</cp:label>
      <cp:nationalCadastralReference>0526601DF3802F</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0526601DF3802F" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430496.65 4582530.72</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0526602DF3802F">
      <cp:areaValue uom="m2">219</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0526602DF3802F" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0526602DF3802F.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="21">430517.04 4582524.76 430512.67 4582520.53 430510.44 4582518.38 430507.39 4582515.44 430506.59 4582514.67 430504.03 4582512.2 430499.61 4582517.71 430498.76 4582518.76 430498.43 4582519.15 430498.13 4582519.49 430497.81 4582519.86 430497.19 4582520.55 430496.09 4582521.8 430498.21 4582523.88 430500.53 4582526.16 430501.19 4582526.81 430501.83 4582527.43 430504 4582529.57 430506.42 4582531.95 430508.27 4582533.77 430517.04 4582524.76</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0526602DF3802F</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>02</cp:label>
      <cp:nationalCadastralReference>0526602DF3802F</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0526602DF3802F" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430507.62 4582524.32</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0526605DF3802F">
      <cp:areaValue uom="m2">906</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0526605DF3802F" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0526605DF3802F.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="27">430518.19 4582493.1 430519.29 4582494.16 430519.98 4582494.84 430521.43 4582496.24 430522.12 4582496.9 430523.82 4582498.55 430526.53 4582501.16 430527.31 4582501.92 430528.15 4582502.74 430533.48 4582507.88 430548.85 4582492.11 430546.6 4582489.96 430542.54 4582486.1 430540.27 4582483.95 430536.61 4582480.47 430532.45 4582476.52 430531.88 4582475.98 430527 4582471.33 430526.31 4582470.68 430520.42 4582465.07 430518.81 4582463.54 430512.53 4582469.99 430503.69 4582479.07 430505.38 4582480.71 430511.22 4582486.36 430516.75 4582491.71 430518.19 4582493.1</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0526605DF3802F</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>05</cp:label>
      <cp:nationalCadastralReference>0526605DF3802F</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0526605DF3802F" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430529.19 4582488.45</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0526623DF3802F">
      <cp:areaValue uom="m2">952</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0526623DF3802F" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0526623DF3802F.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="28">430463.44 4582516.98 430465.39 4582514.94 430467.31 4582512.93 430469.52 4582510.62 430469.84 4582510.29 430472.42 4582507.6 430472.56 4582507.45 430472.78 4582507.22 430475.14 4582504.76 430475.51 4582504.37 430477.02 4582502.79 430479.19 4582500.53 430480.69 4582498.96 430481.8 4582497.8 430483.42 4582496.12 430486.58 4582492.82 430470.16 4582474.53 430468.03 4582472.15 430465.65 4582474.63 430464.94 4582475.36 430464.15 4582476.18 430461.88 4582478.55 430456.15 4582484.5 430451.68 4582489.15 430449.06 4582491.87 430443.6 4582497.54 430447.58 4582501.44 430463.44 4582516.98</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0526623DF3802F</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>23</cp:label>
      <cp:nationalCadastralReference>0526623DF3802F</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0526623DF3802F" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430463.03 4582497.33</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0526624DF3802F">
      <cp:areaValue uom="m2">452</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0526624DF3802F" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0526624DF3802F.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="33">430473.25 4582526.55 430475.28 4582524.43 430477.15 4582522.47 430479.36 4582520.15 430482.36 4582517.03 430482.69 4582516.68 430486.99 4582512.2 430487.75 4582511.39 430489.04 4582510.05 430489.36 4582509.72 430490.49 4582508.54 430493.81 4582505.07 430495.76 4582503.03 430490.42 4582497.1 430488.47 4582494.93 430486.69 4582492.95 430486.58 4582492.82 430483.42 4582496.12 430481.8 4582497.8 430480.69 4582498.96 430479.19 4582500.53 430477.02 4582502.79 430475.51 4582504.37 430475.14 4582504.76 430472.78 4582507.22 430472.56 4582507.45 430472.42 4582507.6 430469.84 4582510.29 430469.52 4582510.62 430467.31 4582512.93 430465.39 4582514.94 430463.44 4582516.98 430473.25 4582526.55</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0526624DF3802F</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>24</cp:label>
      <cp:nationalCadastralReference>0526624DF3802F</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0526624DF3802F" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430477.91 4582511.77</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0526625DF3802F">
      <cp:areaValue uom="m2">426</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0526625DF3802F" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0526625DF3802F.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="29">430483.21 4582536.26 430485.51 4582533.67 430488.2 4582530.64 430489.1 4582529.63 430491.08 4582527.41 430492.18 4582526.18 430496.09 4582521.8 430497.19 4582520.55 430497.81 4582519.86 430498.13 4582519.49 430498.43 4582519.15 430498.76 4582518.76 430499.61 4582517.71 430504.03 4582512.2 430503.85 4582512.03 430495.76 4582503.03 430493.81 4582505.07 430490.49 4582508.54 430489.36 4582509.72 430489.04 4582510.05 430487.75 4582511.39 430486.99 4582512.2 430482.69 4582516.68 430482.36 4582517.03 430479.36 4582520.15 430477.15 4582522.47 430475.28 4582524.43 430473.25 4582526.55 430483.21 4582536.26</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0526625DF3802F</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>25</cp:label>
      <cp:nationalCadastralReference>0526625DF3802F</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0526625DF3802F" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430487.03 4582521.7</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0526626DF3802F">
      <cp:areaValue uom="m2">1061</cp:areaValue>
      <cp:beginLifespanVersion>2009-03-25T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0526626DF3802F" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0526626DF3802F.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="31">430488.47 4582494.93 430490.42 4582497.1 430495.76 4582503.03 430503.85 4582512.03 430504.03 4582512.2 430506.59 4582514.67 430507.39 4582515.44 430510.44 4582518.38 430512.67 4582520.53 430517.04 4582524.76 430525.36 4582516.21 430533.48 4582507.88 430528.15 4582502.74 430527.31 4582501.92 430526.53 4582501.16 430523.82 4582498.55 430522.12 4582496.9 430521.43 4582496.24 430519.98 4582494.84 430519.29 4582494.16 430518.19 4582493.1 430516.75 4582491.71 430511.22 4582486.36 430505.38 4582480.71 430503.69 4582479.07 430512.53 4582469.99 430510.02 4582467.66 430501.47 4582477.01 430486.58 4582492.82 430486.69 4582492.95 430488.47 4582494.93</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0526626DF3802F</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>26</cp:label>
      <cp:nationalCadastralReference>0526626DF3802F</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0526626DF3802F" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430523.29 4582506.08</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0528501DF3802H">
      <cp:areaValue uom="m2">935</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0528501DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0528501DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="18">430521.51 4582712.36 430515.24 4582704.93 430514.59 4582704.16 430512.27 4582701.41 430510.8 4582699.67 430509.61 4582698.28 430508.34 4582696.77 430501.67 4582688.87 430500.79 4582689.95 430492.96 4582699.64 430487.21 4582706.74 430486.91 4582707.11 430484.46 4582710.14 430484.15 4582710.52 430478 4582718.12 430487.34 4582727.22 430507.18 4582726.88 430521.51 4582712.36</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0528501DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>01</cp:label>
      <cp:nationalCadastralReference>0528501DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0528501DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430502.05 4582710.41</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0528502DF3802H">
      <cp:areaValue uom="m2">333</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0528502DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0528502DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="28">430529.01 4582704.79 430525.07 4582700.59 430522.39 4582697.75 430520.81 4582696.07 430520.32 4582695.54 430517.65 4582692.72 430516.4 4582691.38 430515.24 4582690.16 430515.07 4582689.98 430513.65 4582688.46 430507.87 4582682.32 430507.2 4582683.01 430506.08 4582681.86 430504.95 4582680.7 430503.74 4582681.97 430499.6 4582686.3 430498.35 4582687.61 430499.37 4582688.59 430500.79 4582689.95 430501.67 4582688.87 430508.34 4582696.77 430509.61 4582698.28 430510.8 4582699.67 430512.27 4582701.41 430514.59 4582704.16 430515.24 4582704.93 430521.51 4582712.36 430529.01 4582704.79</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0528502DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>02</cp:label>
      <cp:nationalCadastralReference>0528502DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0528502DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430516.44 4582698.49</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0528503DF3802H">
      <cp:areaValue uom="m2">354</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0528503DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0528503DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="24">430504.95 4582680.7 430506.08 4582681.86 430507.2 4582683.01 430507.87 4582682.32 430513.65 4582688.46 430515.07 4582689.98 430515.24 4582690.16 430516.4 4582691.38 430517.65 4582692.72 430520.32 4582695.54 430520.81 4582696.07 430522.39 4582697.75 430525.07 4582700.59 430529.01 4582704.79 430536.93 4582696.8 430536.5 4582696.32 430536.23 4582696.63 430532.07 4582692.52 430529.95 4582690.42 430522.35 4582682.92 430512.3 4582673 430508.3 4582677.2 430505.55 4582680.08 430504.95 4582680.7</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0528503DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>03</cp:label>
      <cp:nationalCadastralReference>0528503DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0528503DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430523.15 4582690.86</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0528504DF3802H">
      <cp:areaValue uom="m2">232</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0528504DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0528504DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="17">430491.22 4582680.75 430493.9 4582683.33 430498.23 4582687.49 430498.35 4582687.61 430499.6 4582686.3 430503.74 4582681.97 430504.95 4582680.7 430505.55 4582680.08 430508.3 4582677.2 430512.3 4582673 430504.22 4582665.07 430500.12 4582669.24 430497.16 4582672.24 430495.48 4582673.96 430491.35 4582678.16 430489.98 4582679.56 430491.22 4582680.75</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0528504DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>04</cp:label>
      <cp:nationalCadastralReference>0528504DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0528504DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430499.78 4582677.73</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0528505DF3802H">
      <cp:areaValue uom="m2">260</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0528505DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0528505DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="18">430489.79 4582682.22 430491.22 4582680.75 430489.98 4582679.56 430491.35 4582678.16 430495.48 4582673.96 430497.16 4582672.24 430500.12 4582669.24 430504.22 4582665.07 430496.04 4582657.05 430491.89 4582661.24 430488.99 4582664.17 430487.28 4582665.9 430483.09 4582670.13 430480.35 4582672.89 430481.27 4582673.8 430485.45 4582677.94 430486.8 4582679.27 430489.79 4582682.22</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0528505DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>05</cp:label>
      <cp:nationalCadastralReference>0528505DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0528505DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430490.11 4582671.19</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0528506DF3802H">
      <cp:areaValue uom="m2">251</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0528506DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0528506DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="16">430472.72 4582665.34 430480.35 4582672.89 430483.09 4582670.13 430487.28 4582665.9 430488.99 4582664.17 430491.89 4582661.24 430496.04 4582657.05 430487.84 4582649.01 430483.69 4582653.27 430480.83 4582656.21 430479.08 4582658.01 430474.98 4582662.23 430475.67 4582662.93 430474.34 4582664.29 430474.03 4582663.97 430472.72 4582665.34</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0528506DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>06</cp:label>
      <cp:nationalCadastralReference>0528506DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0528506DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430482.95 4582662.42</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0528507DF3802H">
      <cp:areaValue uom="m2">255</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0528507DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0528507DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="19">430464.16 4582656.85 430466.71 4582659.34 430471.49 4582664.01 430472.79 4582662.7 430474.03 4582663.97 430474.34 4582664.29 430475.67 4582662.93 430474.98 4582662.23 430479.08 4582658.01 430480.83 4582656.21 430483.69 4582653.27 430487.84 4582649.01 430479.59 4582640.92 430475.41 4582645.23 430472.51 4582648.22 430470.81 4582649.97 430466.71 4582654.21 430465.36 4582655.6 430464.16 4582656.85</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0528507DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>07</cp:label>
      <cp:nationalCadastralReference>0528507DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0528507DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430474.91 4582654.04</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0528508DF3802H">
      <cp:areaValue uom="m2">236</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0528508DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0528508DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="16">430465.36 4582655.6 430466.71 4582654.21 430470.81 4582649.97 430472.51 4582648.22 430475.41 4582645.23 430479.59 4582640.92 430471.41 4582632.89 430467.18 4582637.23 430464.25 4582640.22 430462.53 4582641.97 430458.4 4582646.21 430457.05 4582647.58 430457.32 4582647.85 430458.2 4582648.69 430461.2 4582651.58 430465.36 4582655.6</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0528508DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>08</cp:label>
      <cp:nationalCadastralReference>0528508DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0528508DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430466.97 4582645.64</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0528509DF3802H">
      <cp:areaValue uom="m2">237</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0528509DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0528509DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="15">430448.73 4582639.58 430449.68 4582640.49 430453.46 4582644.13 430457.05 4582647.58 430458.4 4582646.21 430462.53 4582641.97 430464.25 4582640.22 430467.18 4582637.23 430471.41 4582632.89 430463.36 4582624.95 430458.93 4582629.24 430456.04 4582632.17 430454.29 4582633.95 430450.07 4582638.21 430448.73 4582639.58</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0528509DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>09</cp:label>
      <cp:nationalCadastralReference>0528509DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0528509DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430458.68 4582637.67</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0528510DF3802H">
      <cp:areaValue uom="m2">226</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0528510DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0528510DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="14">430441.9 4582630.21 430445.79 4582633.97 430444.42 4582635.44 430448.73 4582639.58 430450.07 4582638.21 430454.29 4582633.95 430456.04 4582632.17 430458.93 4582629.24 430463.36 4582624.95 430455.6 4582617.31 430455.7 4582617.09 430455.25 4582616.72 430450.75 4582621.36 430441.9 4582630.21</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0528510DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>10</cp:label>
      <cp:nationalCadastralReference>0528510DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0528510DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430450.58 4582629.56</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0528511DF3802H">
      <cp:areaValue uom="m2">361</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0528511DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0528511DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="19">430461.2 4582651.58 430458.2 4582648.69 430457.32 4582647.85 430457.05 4582647.58 430453.46 4582644.13 430449.68 4582640.49 430448.73 4582639.58 430444.42 4582635.44 430445.79 4582633.97 430441.9 4582630.21 430430.48 4582642.01 430436.23 4582647.5 430438.52 4582649.67 430442.32 4582653.28 430452.14 4582653.04 430453 4582653.86 430453.97 4582654.78 430456.13 4582656.84 430461.2 4582651.58</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0528511DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>11</cp:label>
      <cp:nationalCadastralReference>0528511DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0528511DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430444.16 4582645.16</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0528512DF3802H">
      <cp:areaValue uom="m2">431</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0528512DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0528512DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="27">430456.13 4582656.84 430453.97 4582654.78 430453 4582653.86 430452.14 4582653.04 430442.32 4582653.28 430438.52 4582649.67 430436.23 4582647.5 430430.48 4582642.01 430426.98 4582645.63 430426.42 4582646.35 430425.93 4582647.23 430425.72 4582647.91 430425.57 4582648.47 430425.76 4582665.31 430425.83 4582665.89 430426.05 4582666.71 430426.41 4582667.47 430426.92 4582668.14 430427.34 4582668.69 430431.09 4582672.31 430436.47 4582666.69 430438.38 4582664.7 430438.6 4582664.46 430442.68 4582660.19 430452.62 4582660.47 430455.26 4582657.73 430456.13 4582656.84</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0528512DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>12</cp:label>
      <cp:nationalCadastralReference>0528512DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0528512DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430439.85 4582659.03</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0528513DF3802H">
      <cp:areaValue uom="m2">355</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0528513DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0528513DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="22">430440.45 4582681.4 430442.62 4582679.16 430444.64 4582677.07 430445.8 4582675.87 430447.6 4582674 430448.11 4582673.49 430450.28 4582671.23 430452.7 4582668.73 430456.8 4582664.48 430457.34 4582663.91 430464.16 4582656.85 430465.36 4582655.6 430461.2 4582651.58 430456.13 4582656.84 430455.26 4582657.73 430452.62 4582660.47 430442.68 4582660.19 430438.6 4582664.46 430438.38 4582664.7 430436.47 4582666.69 430431.09 4582672.31 430440.45 4582681.4</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0528513DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>13</cp:label>
      <cp:nationalCadastralReference>0528513DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0528513DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430443.99 4582668.33</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0528514DF3802H">
      <cp:areaValue uom="m2">414</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0528514DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0528514DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="28">430449.07 4582689.79 430451.32 4582687.47 430453.35 4582685.37 430456.08 4582682.54 430456.36 4582682.26 430458.86 4582679.68 430460.36 4582678.12 430461.39 4582677.06 430463.45 4582674.92 430465.47 4582672.83 430466.01 4582672.28 430472.72 4582665.34 430474.03 4582663.97 430472.79 4582662.7 430471.49 4582664.01 430466.71 4582659.34 430464.16 4582656.85 430457.34 4582663.91 430456.8 4582664.48 430452.7 4582668.73 430450.28 4582671.23 430448.11 4582673.49 430447.6 4582674 430445.8 4582675.87 430444.64 4582677.07 430442.62 4582679.16 430440.45 4582681.4 430449.07 4582689.79</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0528514DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>14</cp:label>
      <cp:nationalCadastralReference>0528514DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0528514DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430454.67 4582675.35</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0528517DF3802H">
      <cp:areaValue uom="m2">537</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0528517DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0528517DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="23">430478 4582718.12 430484.15 4582710.52 430484.46 4582710.14 430486.91 4582707.11 430487.21 4582706.74 430492.96 4582699.64 430500.79 4582689.95 430499.37 4582688.59 430498.35 4582687.61 430498.23 4582687.49 430493.9 4582683.33 430491.22 4582680.75 430489.79 4582682.22 430486.65 4582685.46 430483.79 4582688.41 430482.61 4582689.63 430478.48 4582693.89 430476.07 4582696.37 430473.36 4582699.17 430470.44 4582702.18 430468.33 4582704.36 430466.19 4582706.56 430478 4582718.12</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0528517DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>17</cp:label>
      <cp:nationalCadastralReference>0528517DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0528517DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430481.06 4582701.74</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0528518DF3802H">
      <cp:areaValue uom="m2">814</cp:areaValue>
      <cp:beginLifespanVersion>2003-04-03T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0528518DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0528518DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="28">430457.68 4582698.21 430466.19 4582706.56 430468.33 4582704.36 430470.44 4582702.18 430473.36 4582699.17 430476.07 4582696.37 430478.48 4582693.89 430482.61 4582689.63 430483.79 4582688.41 430486.65 4582685.46 430489.79 4582682.22 430486.8 4582679.27 430485.45 4582677.94 430481.27 4582673.8 430480.35 4582672.89 430472.72 4582665.34 430466.01 4582672.28 430465.47 4582672.83 430463.45 4582674.92 430461.39 4582677.06 430460.36 4582678.12 430458.86 4582679.68 430456.36 4582682.26 430456.08 4582682.54 430453.35 4582685.37 430451.32 4582687.47 430449.07 4582689.79 430457.68 4582698.21</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0528518DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>18</cp:label>
      <cp:nationalCadastralReference>0528518DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0528518DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430467.24 4582687.36</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0529306DF3802H">
      <cp:areaValue uom="m2">426</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0529306DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0529306DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="17">430451.46 4582750.89 430455.45 4582754.82 430457.45 4582756.84 430461.35 4582760.75 430464.92 4582764.23 430467.9 4582767.08 430472.87 4582762.07 430473.28 4582741.48 430465.44 4582733.76 430462.72 4582737.12 430461.07 4582739.15 430459.92 4582740.57 430458.88 4582741.84 430458.07 4582742.84 430455.81 4582745.59 430453.94 4582747.87 430451.46 4582750.89</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0529306DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>06</cp:label>
      <cp:nationalCadastralReference>0529306DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0529306DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430463.07 4582752.48</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0529307DF3802H">
      <cp:areaValue uom="m2">441</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0529307DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0529307DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="14">430453.94 4582747.87 430455.81 4582745.59 430458.07 4582742.84 430458.88 4582741.84 430459.92 4582740.57 430461.07 4582739.15 430462.72 4582737.12 430465.44 4582733.76 430455.27 4582723.96 430448.45 4582717.15 430435.98 4582730 430448.18 4582742.11 430451.06 4582744.98 430453.94 4582747.87</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0529307DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>07</cp:label>
      <cp:nationalCadastralReference>0529307DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0529307DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430452.67 4582734.41</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0529308DF3802H">
      <cp:areaValue uom="m2">408</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0529308DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0529308DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="8">430443.95 4582760.11 430451.46 4582750.89 430453.94 4582747.87 430451.06 4582744.98 430448.18 4582742.11 430435.98 4582730 430425.06 4582741.2 430443.95 4582760.11</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0529308DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>08</cp:label>
      <cp:nationalCadastralReference>0529308DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0529308DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430441.88 4582746.91</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0627601DF3802H">
      <cp:areaValue uom="m2">440</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0627601DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0627601DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="27">430521.3 4582573.46 430526.96 4582567.63 430529.39 4582565.14 430529.93 4582564.58 430532.34 4582562.11 430532.46 4582561.99 430539.96 4582554.31 430540.57 4582553.68 430541.38 4582552.85 430543.39 4582550.77 430541.03 4582548.49 430539.44 4582546.96 430538.08 4582545.65 430537.51 4582545.1 430537.01 4582544.62 430536.64 4582544.26 430531.13 4582538.95 430524.71 4582545.65 430519.74 4582550.83 430519.19 4582551.47 430518.86 4582552 430518.8 4582552.75 430519.08 4582570.26 430519.12 4582571.02 430519.4 4582571.57 430520 4582572.23 430521.3 4582573.46</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0627601DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>01</cp:label>
      <cp:nationalCadastralReference>0627601DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0627601DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430527.46 4582558.34</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0627602DF3802H">
      <cp:areaValue uom="m2">315</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0627602DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0627602DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="20">430521.3 4582573.46 430528.54 4582580.35 430534.56 4582574.14 430536.71 4582571.91 430539.67 4582568.86 430541.1 4582567.39 430547.09 4582561.21 430548.47 4582559.78 430550.53 4582557.66 430548.15 4582555.36 430543.39 4582550.77 430541.38 4582552.85 430540.57 4582553.68 430539.96 4582554.31 430532.46 4582561.99 430532.34 4582562.11 430529.93 4582564.58 430529.39 4582565.14 430526.96 4582567.63 430521.3 4582573.46</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0627602DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>02</cp:label>
      <cp:nationalCadastralReference>0627602DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0627602DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430534.14 4582567.39</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0627603DF3802H">
      <cp:areaValue uom="m2">903</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0627603DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0627603DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="38">430528.54 4582580.35 430540.67 4582592.07 430543 4582589.71 430544.45 4582588.24 430546.29 4582586.37 430546.78 4582585.88 430547.31 4582585.34 430549.77 4582582.86 430552.85 4582579.74 430553.42 4582579.16 430554.71 4582577.85 430560.79 4582571.7 430571.89 4582560.46 430573.69 4582558.63 430574.72 4582557.59 430576.42 4582555.87 430576.92 4582555.37 430578.06 4582554.22 430575.37 4582551.87 430573.22 4582549.99 430568.26 4582545.65 430564.95 4582542.75 430563.54 4582544.21 430562.26 4582545.53 430562.14 4582545.65 430561.39 4582546.43 430559.44 4582548.45 430556.34 4582551.65 430554.9 4582553.14 430551.04 4582557.13 430550.53 4582557.66 430548.47 4582559.78 430547.09 4582561.21 430541.1 4582567.39 430539.67 4582568.86 430536.71 4582571.91 430534.56 4582574.14 430528.54 4582580.35</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0627603DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>03</cp:label>
      <cp:nationalCadastralReference>0627603DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0627603DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430550.07 4582570.45</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0627604DF3802H">
      <cp:areaValue uom="m2">766</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0627604DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0627604DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="39">430540.67 4582592.07 430543.18 4582594.58 430548.18 4582599.59 430550.76 4582602.17 430553.09 4582599.81 430556.41 4582596.44 430557.42 4582595.42 430559.26 4582593.56 430559.91 4582592.9 430562.54 4582590.24 430562.94 4582589.84 430571.04 4582581.63 430583.93 4582568.57 430584.35 4582568.14 430586.72 4582565.74 430587.25 4582565.2 430588.82 4582563.62 430587.92 4582562.83 430586.1 4582561.24 430583.66 4582559.11 430581.57 4582557.28 430580.77 4582556.59 430578.06 4582554.22 430576.92 4582555.37 430576.42 4582555.87 430574.72 4582557.59 430573.69 4582558.63 430571.89 4582560.46 430560.79 4582571.7 430554.71 4582577.85 430553.42 4582579.16 430552.85 4582579.74 430549.77 4582582.86 430547.31 4582585.34 430546.78 4582585.88 430546.29 4582586.37 430544.45 4582588.24 430543 4582589.71 430540.67 4582592.07</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0627604DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>04</cp:label>
      <cp:nationalCadastralReference>0627604DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0627604DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430561.48 4582581.15</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0627605DF3802H">
      <cp:areaValue uom="m2">953</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0627605DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0627605DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="40">430550.76 4582602.17 430553.66 4582604.99 430560.33 4582611.47 430563.25 4582614.3 430565.46 4582612.07 430567.7 4582609.8 430568.98 4582608.51 430571.68 4582605.79 430573.58 4582603.87 430574.93 4582602.5 430576.86 4582600.55 430580.01 4582597.37 430583.14 4582594.2 430583.57 4582593.77 430584.18 4582593.15 430592.1 4582585.13 430593.23 4582583.99 430594.59 4582582.62 430596.81 4582580.37 430599.89 4582577.25 430600.45 4582576.67 430602 4582575.11 430600.97 4582574.21 430598.88 4582572.39 430595.78 4582569.68 430594 4582568.13 430588.82 4582563.62 430587.25 4582565.2 430586.72 4582565.74 430584.35 4582568.14 430583.93 4582568.57 430571.04 4582581.63 430562.94 4582589.84 430562.54 4582590.24 430559.91 4582592.9 430559.26 4582593.56 430557.42 4582595.42 430556.41 4582596.44 430553.09 4582599.81 430550.76 4582602.17</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0627605DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>05</cp:label>
      <cp:nationalCadastralReference>0627605DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0627605DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430572.97 4582592.09</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0627606DF3802H">
      <cp:areaValue uom="m2">495</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0627606DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0627606DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="26">430563.25 4582614.3 430566.4 4582617.39 430572.51 4582623.36 430575.79 4582626.56 430577.92 4582624.4 430578.89 4582623.42 430581.5 4582620.77 430581.61 4582620.66 430584.46 4582617.78 430586.25 4582615.97 430588.88 4582613.31 430592.52 4582609.62 430595.59 4582606.51 430593.06 4582604.01 430590.61 4582601.59 430584.93 4582595.98 430583.14 4582594.2 430580.01 4582597.37 430576.86 4582600.55 430574.93 4582602.5 430573.58 4582603.87 430571.68 4582605.79 430568.98 4582608.51 430567.7 4582609.8 430565.46 4582612.07 430563.25 4582614.3</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0627606DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>06</cp:label>
      <cp:nationalCadastralReference>0627606DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0627606DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430577.48 4582612.38</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0627609DF3802H">
      <cp:areaValue uom="m2">553</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0627609DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0627609DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="24">430610.51 4582621.2 430620.66 4582610.98 430616.99 4582607.37 430611.27 4582601.75 430610.82 4582601.3 430608.84 4582599.36 430608.43 4582598.96 430605.91 4582596.47 430602.29 4582592.91 430600.71 4582591.35 430599.8 4582590.46 430593.23 4582583.99 430592.1 4582585.13 430584.18 4582593.15 430583.57 4582593.77 430583.14 4582594.2 430584.93 4582595.98 430590.61 4582601.59 430593.06 4582604.01 430595.59 4582606.51 430597.91 4582608.79 430598.72 4582609.59 430601.21 4582612.04 430610.51 4582621.2</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0627609DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>09</cp:label>
      <cp:nationalCadastralReference>0627609DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0627609DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430604.21 4582604.89</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0627610DF3802H">
      <cp:areaValue uom="m2">549</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0627610DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0627610DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="33">430620.66 4582610.98 430630.81 4582600.67 430626.68 4582596.61 430624.86 4582594.82 430623.62 4582593.6 430621.75 4582591.76 430621.04 4582591.06 430618.63 4582588.69 430618.09 4582588.16 430614.72 4582584.84 430612.41 4582582.58 430612.01 4582582.18 430610.79 4582580.98 430610.01 4582580.22 430606.45 4582576.71 430605.26 4582577.95 430602.79 4582575.8 430602 4582575.11 430600.45 4582576.67 430599.89 4582577.25 430596.81 4582580.37 430594.59 4582582.62 430593.23 4582583.99 430599.8 4582590.46 430600.71 4582591.35 430602.29 4582592.91 430605.91 4582596.47 430608.43 4582598.96 430608.84 4582599.36 430610.82 4582601.3 430611.27 4582601.75 430616.99 4582607.37 430620.66 4582610.98</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0627610DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>10</cp:label>
      <cp:nationalCadastralReference>0627610DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0627610DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430614.99 4582595.26</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0627611DF3802H">
      <cp:areaValue uom="m2">781</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0627611DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0627611DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="38">430630.81 4582600.67 430634.35 4582596.98 430643.24 4582587.74 430646.72 4582584.12 430645.16 4582582.6 430642.97 4582580.46 430642.61 4582580.12 430641.25 4582578.8 430640.77 4582578.32 430639.52 4582577.11 430639.22 4582576.82 430637.63 4582575.28 430637.36 4582575.01 430634.98 4582572.69 430634.1 4582571.84 430631.79 4582569.6 430630.82 4582568.65 430630.11 4582567.96 430627.99 4582565.9 430626.53 4582564.48 430626.15 4582564.11 430624.05 4582562.07 430622.23 4582560.3 430607.87 4582575.23 430606.45 4582576.71 430610.01 4582580.22 430610.79 4582580.98 430612.01 4582582.18 430612.41 4582582.58 430614.72 4582584.84 430618.09 4582588.16 430618.63 4582588.69 430621.04 4582591.06 430621.75 4582591.76 430623.62 4582593.6 430624.86 4582594.82 430626.68 4582596.61 430630.81 4582600.67</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0627611DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>11</cp:label>
      <cp:nationalCadastralReference>0627611DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0627611DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430629.18 4582582.97</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0627612DF3802H">
      <cp:areaValue uom="m2">251</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0627612DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0627612DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="37">430646.72 4582584.12 430651.81 4582578.83 430650.22 4582577.28 430648.1 4582575.22 430647.6 4582574.73 430646.07 4582573.25 430643.57 4582570.81 430641.62 4582568.91 430640.79 4582568.1 430638.67 4582566.04 430635.84 4582563.29 430635.27 4582562.73 430633.13 4582560.65 430632.61 4582560.14 430631.71 4582559.27 430631.39 4582558.95 430627.33 4582555.01 430622.23 4582560.3 430624.05 4582562.07 430626.15 4582564.11 430626.53 4582564.48 430627.99 4582565.9 430630.11 4582567.96 430630.82 4582568.65 430631.79 4582569.6 430634.1 4582571.84 430634.98 4582572.69 430637.36 4582575.01 430637.63 4582575.28 430639.22 4582576.82 430639.52 4582577.11 430640.77 4582578.32 430641.25 4582578.8 430642.61 4582580.12 430642.97 4582580.46 430645.16 4582582.6 430646.72 4582584.12</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0627612DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>12</cp:label>
      <cp:nationalCadastralReference>0627612DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0627612DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430638.87 4582571.36</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0627613DF3802H">
      <cp:areaValue uom="m2">502</cp:areaValue>
      <cp:beginLifespanVersion>2007-05-11T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0627613DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0627613DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="26">430660.61 4582569.55 430660.74 4582562.47 430660.84 4582556.96 430660.98 4582549.99 430660.65 4582549.66 430656.59 4582545.65 430654.92 4582544 430653.3 4582545.65 430649.7 4582549.31 430648.34 4582550.68 430648.23 4582550.79 430644.73 4582554.31 430644.4 4582554.64 430641.16 4582557.91 430635.84 4582563.29 430638.67 4582566.04 430640.79 4582568.1 430641.62 4582568.91 430643.57 4582570.81 430646.07 4582573.25 430647.6 4582574.73 430648.1 4582575.22 430650.22 4582577.28 430651.81 4582578.83 430660.6 4582569.82 430660.61 4582569.55</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0627613DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>13</cp:label>
      <cp:nationalCadastralReference>0627613DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0627613DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430651.19 4582560.24</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0627614DF3802H">
      <cp:areaValue uom="m2">327</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0627614DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0627614DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="24">430627.33 4582555.01 430631.39 4582558.95 430631.71 4582559.27 430632.61 4582560.14 430633.13 4582560.65 430635.27 4582562.73 430635.84 4582563.29 430641.16 4582557.91 430644.4 4582554.64 430644.73 4582554.31 430648.23 4582550.79 430648.34 4582550.68 430649.7 4582549.31 430653.3 4582545.65 430654.92 4582544 430646.21 4582535.47 430641.1 4582540.76 430636.38 4582545.65 430634.07 4582548.03 430632.86 4582549.28 430629.2 4582553.08 430628.13 4582554.18 430627.56 4582554.77 430627.33 4582555.01</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0627614DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>14</cp:label>
      <cp:nationalCadastralReference>0627614DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0627614DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430639.52 4582551.1</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0627615DF3802H">
      <cp:areaValue uom="m2">860</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0627615DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0627615DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="29">430606.45 4582576.71 430607.87 4582575.23 430622.23 4582560.3 430627.33 4582555.01 430627.56 4582554.77 430628.13 4582554.18 430629.2 4582553.08 430632.86 4582549.28 430634.07 4582548.03 430636.38 4582545.65 430641.1 4582540.76 430646.21 4582535.47 430636.27 4582525.57 430626.27 4582535.63 430622.64 4582539.28 430617.27 4582544.69 430616.31 4582545.65 430615.53 4582546.43 430614.54 4582547.43 430602.34 4582559.72 430597.39 4582564.72 430594 4582568.13 430595.78 4582569.68 430598.88 4582572.39 430600.97 4582574.21 430602 4582575.11 430602.79 4582575.8 430605.26 4582577.95 430606.45 4582576.71</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0627615DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>15</cp:label>
      <cp:nationalCadastralReference>0627615DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0627615DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430617.19 4582554.99</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0627616DF3802H">
      <cp:areaValue uom="m2">847</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0627616DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0627616DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="29">430588.82 4582563.62 430594 4582568.13 430597.39 4582564.72 430602.34 4582559.72 430614.54 4582547.43 430615.53 4582546.43 430616.31 4582545.65 430617.27 4582544.69 430622.64 4582539.28 430626.27 4582535.63 430636.27 4582525.57 430626.06 4582515.48 430619.64 4582522.09 430618.15 4582523.62 430616.14 4582525.69 430614.23 4582527.65 430612.57 4582529.37 430611.92 4582530.04 430607.22 4582534.87 430605.5 4582536.64 430603.13 4582539.08 430599.63 4582542.68 430596.74 4582545.65 430587.33 4582555.34 430587.18 4582555.49 430583.66 4582559.11 430586.1 4582561.24 430587.92 4582562.83 430588.82 4582563.62</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0627616DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>16</cp:label>
      <cp:nationalCadastralReference>0627616DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0627616DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430607.11 4582545.06</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0627617DF3802H">
      <cp:areaValue uom="m2">852</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0627617DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0627617DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="35">430578.06 4582554.22 430580.77 4582556.59 430581.57 4582557.28 430583.66 4582559.11 430587.18 4582555.49 430587.33 4582555.34 430596.74 4582545.65 430599.63 4582542.68 430603.13 4582539.08 430605.5 4582536.64 430607.22 4582534.87 430611.92 4582530.04 430612.57 4582529.37 430614.23 4582527.65 430616.14 4582525.69 430618.15 4582523.62 430619.64 4582522.09 430626.06 4582515.48 430616.07 4582505.71 430609.67 4582512.32 430608.15 4582513.89 430607.06 4582515.02 430604.27 4582517.91 430603.75 4582518.44 430601.95 4582520.3 430596.33 4582526.11 430593.41 4582529.13 430593.2 4582529.35 430584.26 4582538.59 430582.76 4582540.13 430577.42 4582545.65 430577.32 4582545.75 430573.22 4582549.99 430575.37 4582551.87 430578.06 4582554.22</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0627617DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>17</cp:label>
      <cp:nationalCadastralReference>0627617DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0627617DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430596.72 4582535.71</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0627618DF3802H">
      <cp:areaValue uom="m2">845</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0627618DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0627618DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="40">430573.22 4582549.99 430577.32 4582545.75 430577.42 4582545.65 430582.76 4582540.13 430584.26 4582538.59 430593.2 4582529.35 430593.41 4582529.13 430596.33 4582526.11 430601.95 4582520.3 430603.75 4582518.44 430604.27 4582517.91 430607.06 4582515.02 430608.15 4582513.89 430609.67 4582512.32 430616.07 4582505.71 430606.25 4582496.24 430602.7 4582499.89 430599.24 4582503.45 430597.24 4582505.51 430595.37 4582507.44 430593.99 4582508.85 430593.08 4582509.79 430591.18 4582511.74 430587.92 4582515.1 430585.89 4582517.19 430584.96 4582518.14 430583.78 4582519.35 430583.57 4582519.57 430579.48 4582523.77 430578.1 4582525.19 430574.35 4582529.05 430573.76 4582529.65 430572.91 4582530.53 430572.53 4582530.17 430571.71 4582531.24 430568.8 4582535.02 430563.7 4582541.65 430564.95 4582542.75 430568.26 4582545.65 430573.22 4582549.99</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0627618DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>18</cp:label>
      <cp:nationalCadastralReference>0627618DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0627618DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430586.46 4582526.43</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0627619DF3802H">
      <cp:areaValue uom="m2">425</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0627619DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0627619DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="16">430606.25 4582496.24 430598.91 4582489.1 430579.36 4582489.24 430573.93 4582494.82 430579.69 4582500.43 430581.74 4582502.45 430587.44 4582508.08 430587.74 4582508.38 430591.18 4582511.74 430593.08 4582509.79 430593.99 4582508.85 430595.37 4582507.44 430597.24 4582505.51 430599.24 4582503.45 430602.7 4582499.89 430606.25 4582496.24</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0627619DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>19</cp:label>
      <cp:nationalCadastralReference>0627619DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0627619DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430590.74 4582496.16</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0627620DF3802H">
      <cp:areaValue uom="m2">219</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0627620DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0627620DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="14">430584.96 4582518.14 430585.89 4582517.19 430587.92 4582515.1 430591.18 4582511.74 430587.74 4582508.38 430587.44 4582508.08 430581.74 4582502.45 430579.69 4582500.43 430573.93 4582494.82 430567.52 4582501.39 430573.02 4582506.66 430581.12 4582514.46 430583.98 4582517.2 430584.96 4582518.14</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0627620DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>20</cp:label>
      <cp:nationalCadastralReference>0627620DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0627620DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430580.8 4582507.92</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0627621DF3802H">
      <cp:areaValue uom="m2">419</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0627621DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0627621DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="21">430584.96 4582518.14 430583.98 4582517.2 430581.12 4582514.46 430573.02 4582506.66 430567.52 4582501.39 430555.43 4582513.81 430560.95 4582519.08 430566.54 4582524.43 430568.95 4582526.74 430569.92 4582527.67 430570.12 4582527.86 430571.9 4582529.57 430572.53 4582530.17 430572.91 4582530.53 430573.76 4582529.65 430574.35 4582529.05 430578.1 4582525.19 430579.48 4582523.77 430583.57 4582519.57 430583.78 4582519.35 430584.96 4582518.14</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0627621DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>21</cp:label>
      <cp:nationalCadastralReference>0627621DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0627621DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430572.06 4582517.76</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0627622DF3802H">
      <cp:areaValue uom="m2">488</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0627622DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0627622DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="27">430564.95 4582542.75 430563.7 4582541.65 430568.8 4582535.02 430571.71 4582531.24 430572.53 4582530.17 430571.9 4582529.57 430570.12 4582527.86 430569.92 4582527.67 430568.95 4582526.74 430566.54 4582524.43 430560.95 4582519.08 430555.43 4582513.81 430541.92 4582527.68 430547.49 4582533.04 430547.92 4582533.45 430551.88 4582537.27 430553.16 4582538.5 430556.62 4582541.84 430557.69 4582542.87 430558.12 4582543.29 430560.34 4582545.42 430560.58 4582545.65 430561.39 4582546.43 430562.14 4582545.65 430562.26 4582545.53 430563.54 4582544.21 430564.95 4582542.75</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0627622DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>22</cp:label>
      <cp:nationalCadastralReference>0627622DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0627622DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430558.78 4582532.13</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0627623DF3802H">
      <cp:areaValue uom="m2">421</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0627623DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0627623DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="27">430543.39 4582550.77 430548.15 4582555.36 430550.53 4582557.66 430551.04 4582557.13 430554.9 4582553.14 430556.34 4582551.65 430559.44 4582548.45 430561.39 4582546.43 430560.58 4582545.65 430560.34 4582545.42 430558.12 4582543.29 430557.69 4582542.87 430556.62 4582541.84 430553.16 4582538.5 430551.88 4582537.27 430547.92 4582533.45 430547.49 4582533.04 430541.92 4582527.68 430537.8 4582531.99 430531.13 4582538.95 430536.64 4582544.26 430537.01 4582544.62 430537.51 4582545.1 430538.08 4582545.65 430539.44 4582546.96 430541.03 4582548.49 430543.39 4582550.77</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0627623DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>23</cp:label>
      <cp:nationalCadastralReference>0627623DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0627623DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430548.16 4582544.52</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0627624DF3802H">
      <cp:areaValue uom="m2">491</cp:areaValue>
      <cp:beginLifespanVersion>2003-02-26T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0627624DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0627624DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="18">430603.97 4582627.95 430610.51 4582621.2 430601.21 4582612.04 430598.72 4582609.59 430597.91 4582608.79 430595.59 4582606.51 430592.52 4582609.62 430588.88 4582613.31 430586.25 4582615.97 430584.46 4582617.78 430581.61 4582620.66 430581.5 4582620.77 430578.89 4582623.42 430577.92 4582624.4 430575.79 4582626.56 430580.73 4582631.37 430600.81 4582631.2 430603.97 4582627.95</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0627624DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>24</cp:label>
      <cp:nationalCadastralReference>0627624DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0627624DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430585.52 4582627.43</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.06276W6DF3802H">
      <cp:areaValue uom="m2">5</cp:areaValue>
      <cp:beginLifespanVersion>2012-02-24T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.06276W6DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.06276W6DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5">430585.49 4582637.4 430587.77 4582637.4 430587.77 4582634.94 430585.6 4582634.94 430585.49 4582637.4</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>06276W6DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>W6</cp:label>
      <cp:nationalCadastralReference>06276W6DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.06276W6DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430587.2 4582636.78</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0628201DF3802H">
      <cp:areaValue uom="m2">216</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0628201DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0628201DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="16">430551.82 4582681.32 430548 4582677.61 430549.25 4582676.34 430548.54 4582675.64 430545.09 4582672.21 430543.82 4582673.51 430541.23 4582676.15 430539.7 4582677.72 430537.95 4582679.52 430535.23 4582682.3 430531.04 4582686.61 430538.59 4582694.01 430538.38 4582694.28 430538.88 4582694.67 430543.26 4582690.15 430551.82 4582681.32</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0628201DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>01</cp:label>
      <cp:nationalCadastralReference>0628201DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0628201DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430540.59 4582684.83</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0628202DF3802H">
      <cp:areaValue uom="m2">284</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0628202DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0628202DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="22">430545.09 4582672.21 430548.54 4582675.64 430549.25 4582676.34 430548 4582677.61 430551.82 4582681.32 430562.85 4582669.96 430559.33 4582666.52 430559.04 4582666.24 430557.46 4582664.69 430555.49 4582662.75 430553.7 4582660.98 430552.36 4582659.66 430552.23 4582659.53 430548.88 4582656.21 430548.26 4582656.86 430547.91 4582657.22 430546.57 4582658.62 430540.19 4582665.27 430539.17 4582666.32 430542.53 4582669.67 430544.39 4582671.51 430545.09 4582672.21</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0628202DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>02</cp:label>
      <cp:nationalCadastralReference>0628202DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0628202DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430552.85 4582670.32</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0628203DF3802H">
      <cp:areaValue uom="m2">293</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0628203DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0628203DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="30">430548.88 4582656.21 430552.23 4582659.53 430552.36 4582659.66 430553.7 4582660.98 430555.49 4582662.75 430557.46 4582664.69 430559.04 4582666.24 430559.33 4582666.52 430562.85 4582669.96 430564.27 4582668.5 430565.36 4582667.41 430566.15 4582666.34 430566.6 4582665.35 430566.76 4582664.56 430566.78 4582663.73 430566.87 4582653.3 430566.93 4582649.53 430566.94 4582647.55 430566.63 4582646.19 430566.07 4582645.2 430565.2 4582644.29 430562.68 4582641.82 430559.18 4582645.47 430558.84 4582645.82 430556.68 4582648.08 430555.84 4582648.96 430554.57 4582650.28 430554.38 4582650.48 430552.34 4582652.61 430548.88 4582656.21</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0628203DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>03</cp:label>
      <cp:nationalCadastralReference>0628203DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0628203DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430558.57 4582657.63</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0628204DF3802H">
      <cp:areaValue uom="m2">399</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0628204DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0628204DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="27">430539.17 4582666.32 430540.19 4582665.27 430546.57 4582658.62 430547.91 4582657.22 430548.26 4582656.86 430548.88 4582656.21 430552.34 4582652.61 430554.38 4582650.48 430554.57 4582650.28 430555.84 4582648.96 430556.68 4582648.08 430558.84 4582645.82 430559.18 4582645.47 430562.68 4582641.82 430554.42 4582633.75 430550.65 4582637.57 430547.54 4582640.74 430546.01 4582642.29 430544.85 4582643.47 430538.67 4582649.74 430538.11 4582650.3 430535.98 4582652.46 430531.59 4582656.91 430530.66 4582657.85 430536.99 4582664.15 430537.76 4582664.91 430539.17 4582666.32</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0628204DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>04</cp:label>
      <cp:nationalCadastralReference>0628204DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0628204DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430544.63 4582652.05</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0628205DF3802H">
      <cp:areaValue uom="m2">408</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0628205DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0628205DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="28">430528.89 4582656.09 430530.66 4582657.85 430531.59 4582656.91 430535.98 4582652.46 430538.11 4582650.3 430538.67 4582649.74 430544.85 4582643.47 430546.01 4582642.29 430547.54 4582640.74 430550.65 4582637.57 430554.42 4582633.75 430545.69 4582625.23 430543.63 4582627.36 430541.97 4582629.06 430540.99 4582630.07 430538.86 4582632.28 430536.19 4582635.03 430533.63 4582637.67 430529.52 4582641.9 430527.89 4582643.58 430527.38 4582644.1 430523.64 4582647.96 430523 4582648.62 430522.2 4582649.44 430522.87 4582650.11 430523.99 4582651.22 430524.35 4582651.58 430528.89 4582656.09</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0628205DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>05</cp:label>
      <cp:nationalCadastralReference>0628205DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0628205DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430536.33 4582643.56</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0628206DF3802H">
      <cp:areaValue uom="m2">382</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0628206DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0628206DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="24">430515.1 4582639.33 430523.64 4582647.96 430527.38 4582644.1 430527.89 4582643.58 430529.52 4582641.9 430533.63 4582637.67 430536.19 4582635.03 430538.86 4582632.28 430540.99 4582630.07 430541.97 4582629.06 430543.63 4582627.36 430545.69 4582625.23 430543.54 4582623.13 430539.15 4582618.85 430537.05 4582616.8 430535.03 4582618.88 430533.39 4582620.55 430532.34 4582621.64 430530.24 4582623.79 430527.49 4582626.61 430524.89 4582629.28 430520.85 4582633.43 430519.2 4582635.12 430515.1 4582639.33</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0628206DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>06</cp:label>
      <cp:nationalCadastralReference>0628206DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0628206DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430528.44 4582634.3</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0628207DF3802H">
      <cp:areaValue uom="m2">408</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0628207DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0628207DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="19">430512.55 4582639.93 430513.55 4582640.92 430515.1 4582639.33 430519.2 4582635.12 430520.85 4582633.43 430524.89 4582629.28 430527.49 4582626.61 430530.24 4582623.79 430532.34 4582621.64 430533.39 4582620.55 430535.03 4582618.88 430537.05 4582616.8 430528.35 4582608.29 430524.46 4582612.31 430521.46 4582615.4 430518.89 4582618.05 430512.19 4582624.97 430504.93 4582632.47 430512.55 4582639.93</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0628207DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>07</cp:label>
      <cp:nationalCadastralReference>0628207DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0628207DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430519.04 4582626.62</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0628208DF3802H">
      <cp:areaValue uom="m2">401</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0628208DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0628208DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="18">430504.4 4582631.94 430504.93 4582632.47 430512.19 4582624.97 430518.89 4582618.05 430521.46 4582615.4 430524.46 4582612.31 430528.35 4582608.29 430519.87 4582600.01 430514.52 4582605.5 430512.93 4582607.13 430512.21 4582607.88 430510.36 4582609.78 430503.67 4582616.64 430501.81 4582618.56 430501.46 4582618.91 430496.33 4582624.04 430500 4582627.64 430504.4 4582631.94</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0628208DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>08</cp:label>
      <cp:nationalCadastralReference>0628208DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0628208DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430510.41 4582618.24</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0628209DF3802H">
      <cp:areaValue uom="m2">336</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0628209DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0628209DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="17">430496.33 4582624.04 430501.46 4582618.91 430501.81 4582618.56 430503.67 4582616.64 430510.36 4582609.78 430512.21 4582607.88 430512.93 4582607.13 430514.52 4582605.5 430519.87 4582600.01 430510.55 4582590.89 430504.96 4582596.6 430502.9 4582598.69 430502.47 4582599.14 430499.1 4582602.57 430499.66 4582612.77 430492.32 4582620.1 430496.33 4582624.04</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0628209DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>09</cp:label>
      <cp:nationalCadastralReference>0628209DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0628209DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430509.56 4582601.22</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0628210DF3802H">
      <cp:areaValue uom="m2">314</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0628210DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0628210DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="15">430499.1 4582602.57 430502.47 4582599.14 430502.9 4582598.69 430504.96 4582596.6 430510.55 4582590.89 430505.16 4582585.62 430485.36 4582585.88 430481.8 4582589.52 430487.56 4582595.18 430489.74 4582597.32 430492.23 4582599.78 430493.74 4582601.26 430495.94 4582603.43 430497.13 4582604.59 430499.1 4582602.57</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0628210DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>10</cp:label>
      <cp:nationalCadastralReference>0628210DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0628210DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430496.88 4582591.53</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0628211DF3802H">
      <cp:areaValue uom="m2">425</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0628211DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0628211DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="17">430488.13 4582616 430492.32 4582620.1 430499.66 4582612.77 430499.1 4582602.57 430497.13 4582604.59 430495.94 4582603.43 430493.74 4582601.26 430492.23 4582599.78 430489.74 4582597.32 430487.56 4582595.18 430481.8 4582589.52 430470.22 4582601.36 430473.41 4582604.42 430474.13 4582605.1 430475.61 4582603.72 430479.9 4582607.93 430488.13 4582616</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0628211DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>11</cp:label>
      <cp:nationalCadastralReference>0628211DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0628211DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430488.99 4582606.7</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0628212DF3802H">
      <cp:areaValue uom="m2">224</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0628212DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0628212DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="15">430479.9 4582607.93 430475.61 4582603.72 430474.13 4582605.1 430473.41 4582604.42 430470.22 4582601.36 430461.52 4582610.26 430457.18 4582614.69 430457.58 4582615.02 430457.83 4582614.82 430465.7 4582622.55 430469.81 4582618.32 430472.46 4582615.59 430474.17 4582613.83 430478.49 4582609.38 430479.9 4582607.93</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0628212DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>12</cp:label>
      <cp:nationalCadastralReference>0628212DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0628212DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430466.65 4582613.26</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0628213DF3802H">
      <cp:areaValue uom="m2">235</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0628213DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0628213DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="13">430473.94 4582630.63 430478.08 4582626.37 430480.69 4582623.68 430482.4 4582621.92 430486.73 4582617.45 430488.13 4582616 430479.9 4582607.93 430478.49 4582609.38 430474.17 4582613.83 430472.46 4582615.59 430469.81 4582618.32 430465.7 4582622.55 430473.94 4582630.63</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0628213DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>13</cp:label>
      <cp:nationalCadastralReference>0628213DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0628213DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430475.55 4582620.68</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0628214DF3802H">
      <cp:areaValue uom="m2">234</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0628214DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0628214DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="14">430482.09 4582638.62 430486.24 4582634.41 430488.92 4582631.7 430490.57 4582630.02 430494.98 4582625.54 430496.33 4582624.04 430492.32 4582620.1 430488.13 4582616 430486.73 4582617.45 430482.4 4582621.92 430480.69 4582623.68 430478.08 4582626.37 430473.94 4582630.63 430482.09 4582638.62</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0628214DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>14</cp:label>
      <cp:nationalCadastralReference>0628214DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0628214DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430483.84 4582628.7</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0628215DF3802H">
      <cp:areaValue uom="m2">230</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0628215DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0628215DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="14">430490.22 4582646.59 430494.32 4582642.35 430496.97 4582639.62 430498.74 4582637.78 430502.99 4582633.4 430504.4 4582631.94 430500 4582627.64 430496.33 4582624.04 430494.98 4582625.54 430490.57 4582630.02 430488.92 4582631.7 430486.24 4582634.41 430482.09 4582638.62 430490.22 4582646.59</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0628215DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>15</cp:label>
      <cp:nationalCadastralReference>0628215DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0628215DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430491.88 4582636.71</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0628216DF3802H">
      <cp:areaValue uom="m2">234</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0628216DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0628216DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="14">430498.42 4582654.64 430502.51 4582650.39 430505.14 4582647.64 430506.88 4582645.84 430511.15 4582641.39 430512.55 4582639.93 430504.93 4582632.47 430504.4 4582631.94 430502.99 4582633.4 430498.74 4582637.78 430496.97 4582639.62 430494.32 4582642.35 430490.22 4582646.59 430498.42 4582654.64</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0628216DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>16</cp:label>
      <cp:nationalCadastralReference>0628216DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0628216DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430500.02 4582644.69</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0628217DF3802H">
      <cp:areaValue uom="m2">260</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0628217DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0628217DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="18">430506.55 4582662.61 430510.67 4582658.41 430513.37 4582655.66 430515.17 4582653.83 430519.41 4582649.51 430520.82 4582648.07 430522.2 4582649.44 430523 4582648.62 430523.64 4582647.96 430515.1 4582639.33 430513.55 4582640.92 430512.55 4582639.93 430511.15 4582641.39 430506.88 4582645.84 430505.14 4582647.64 430502.51 4582650.39 430498.42 4582654.64 430506.55 4582662.61</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0628217DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>17</cp:label>
      <cp:nationalCadastralReference>0628217DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0628217DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430508.56 4582652.41</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0628218DF3802H">
      <cp:areaValue uom="m2">231</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0628218DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0628218DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="17">430514.61 4582670.53 430518.82 4582666.27 430521.51 4582663.56 430523.29 4582661.76 430527.52 4582657.49 430528.89 4582656.09 430524.35 4582651.58 430523.99 4582651.22 430522.87 4582650.11 430522.2 4582649.44 430520.82 4582648.07 430519.41 4582649.51 430515.17 4582653.83 430513.37 4582655.66 430510.67 4582658.41 430506.55 4582662.61 430514.61 4582670.53</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0628218DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>18</cp:label>
      <cp:nationalCadastralReference>0628218DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0628218DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430516.4 4582660.68</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0628219DF3802H">
      <cp:areaValue uom="m2">233</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0628219DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0628219DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="14">430522.89 4582678.63 430527.07 4582674.34 430529.77 4582671.57 430531.53 4582669.76 430535.67 4582665.51 430536.99 4582664.15 430530.66 4582657.85 430528.89 4582656.09 430527.52 4582657.49 430523.29 4582661.76 430521.51 4582663.56 430518.82 4582666.27 430514.61 4582670.53 430522.89 4582678.63</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0628219DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>19</cp:label>
      <cp:nationalCadastralReference>0628219DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0628219DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430524.44 4582668.75</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0628220DF3802H">
      <cp:areaValue uom="m2">230</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0628220DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0628220DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="18">430531.04 4582686.61 430535.23 4582682.3 430537.95 4582679.52 430539.7 4582677.72 430541.23 4582676.15 430543.82 4582673.51 430545.09 4582672.21 430544.39 4582671.51 430542.53 4582669.67 430539.17 4582666.32 430537.76 4582664.91 430536.99 4582664.15 430535.67 4582665.51 430531.53 4582669.76 430529.77 4582671.57 430527.07 4582674.34 430522.89 4582678.63 430531.04 4582686.61</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0628220DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>20</cp:label>
      <cp:nationalCadastralReference>0628220DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0628220DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430532.67 4582676.77</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0629601DF3802H">
      <cp:areaValue uom="m2">725</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0629601DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0629601DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="25">430551.5 4582748.12 430549.51 4582745.75 430546.76 4582742.47 430545.85 4582741.39 430543.38 4582738.44 430543.22 4582738.25 430540.02 4582734.44 430539.55 4582733.88 430537.82 4582731.82 430536.3 4582730.01 430534.39 4582727.73 430521.48 4582741.03 430521.76 4582760.79 430530.63 4582769.45 430532.62 4582767.41 430534 4582766 430536.55 4582763.38 430536.93 4582762.99 430538.66 4582761.21 430540.45 4582759.37 430542.89 4582756.87 430545.1 4582754.6 430546.22 4582753.46 430547.51 4582752.13 430551.5 4582748.12</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0629601DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>01</cp:label>
      <cp:nationalCadastralReference>0629601DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0629601DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430535.05 4582751.16</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0629602DF3802H">
      <cp:areaValue uom="m2">273</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0629602DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0629602DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="19">430530.63 4582769.45 430537.25 4582775.91 430542.62 4582770.45 430545.16 4582767.86 430551.79 4582761.11 430554.17 4582758.67 430557.51 4582755.28 430551.5 4582748.12 430547.51 4582752.13 430546.22 4582753.46 430545.1 4582754.6 430542.89 4582756.87 430540.45 4582759.37 430538.66 4582761.21 430536.93 4582762.99 430536.55 4582763.38 430534 4582766 430532.62 4582767.41 430530.63 4582769.45</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0629602DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>02</cp:label>
      <cp:nationalCadastralReference>0629602DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0629602DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430542.71 4582763.73</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0629613DF3802H">
      <cp:areaValue uom="m2">533</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0629613DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0629613DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="24">430640.81 4582781.31 430644.89 4582777.13 430652.48 4582769.36 430656.56 4582765.2 430655.61 4582764.29 430651.28 4582760.11 430648.8 4582757.73 430647.13 4582756.13 430646.46 4582755.49 430644.04 4582753.17 430639.17 4582748.49 430637.98 4582749.71 430636.86 4582750.88 430633.86 4582753.97 430629.38 4582758.62 430625.29 4582762.86 430624.06 4582764.14 430628.64 4582768.83 430632.06 4582772.34 430633.2 4582773.51 430634.63 4582774.97 430635.6 4582775.97 430639.8 4582780.27 430640.81 4582781.31</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0629613DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>13</cp:label>
      <cp:nationalCadastralReference>0629613DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0629613DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430640.82 4582766.93</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0629614DF3802H">
      <cp:areaValue uom="m2">224</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0629614DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0629614DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="16">430646.46 4582755.49 430647.13 4582756.13 430648.8 4582757.73 430651.28 4582760.11 430655.61 4582764.29 430656.56 4582765.2 430662.66 4582759 430662.33 4582739.22 430662.08 4582738.97 430657.22 4582744.15 430655.3 4582746.19 430653.87 4582747.69 430652.16 4582749.49 430650.37 4582751.37 430649.71 4582752.06 430646.46 4582755.49</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0629614DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>14</cp:label>
      <cp:nationalCadastralReference>0629614DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0629614DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430655.36 4582753.71</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0629615DF3802H">
      <cp:areaValue uom="m2">227</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0629615DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0629615DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="17">430639.17 4582748.49 430644.04 4582753.17 430646.46 4582755.49 430649.71 4582752.06 430650.37 4582751.37 430652.16 4582749.49 430653.87 4582747.69 430655.3 4582746.19 430657.22 4582744.15 430662.08 4582738.97 430655.07 4582732.1 430648.65 4582738.74 430646.99 4582740.44 430645.51 4582741.97 430643.23 4582744.31 430642.52 4582745.04 430639.17 4582748.49</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0629615DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>15</cp:label>
      <cp:nationalCadastralReference>0629615DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0629615DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430656.82 4582734.43</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0629616DF3802H">
      <cp:areaValue uom="m2">654</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0629616DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0629616DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="24">430614.4 4582754.24 430621.14 4582761.14 430622.53 4582762.57 430624.06 4582764.14 430625.29 4582762.86 430629.38 4582758.62 430633.86 4582753.97 430636.86 4582750.88 430637.98 4582749.71 430639.17 4582748.49 430642.52 4582745.04 430643.23 4582744.31 430645.51 4582741.97 430646.99 4582740.44 430648.65 4582738.74 430655.07 4582732.1 430644.54 4582721.77 430638.15 4582728.38 430635.04 4582731.6 430631.3 4582735.46 430626.45 4582740.47 430626.35 4582740.58 430613.78 4582753.6 430614.4 4582754.24</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0629616DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>16</cp:label>
      <cp:nationalCadastralReference>0629616DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0629616DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430631.77 4582745.57</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0629617DF3802H">
      <cp:areaValue uom="m2">631</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0629617DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0629617DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="16">430603.22 4582744.09 430613.78 4582753.6 430626.35 4582740.58 430626.45 4582740.47 430631.3 4582735.46 430635.04 4582731.6 430638.15 4582728.38 430644.54 4582721.77 430634.48 4582711.89 430628 4582718.56 430627.07 4582719.53 430623.74 4582722.96 430621.23 4582725.53 430616.42 4582730.49 430615.06 4582731.89 430603.22 4582744.09</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0629617DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>17</cp:label>
      <cp:nationalCadastralReference>0629617DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0629617DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430621.58 4582735.32</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0629618DF3802H">
      <cp:areaValue uom="m2">263</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0629618DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0629618DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="24">430598.99 4582740.2 430603.22 4582744.09 430615.06 4582731.89 430616.42 4582730.49 430621.23 4582725.53 430623.74 4582722.96 430627.07 4582719.53 430628 4582718.56 430634.48 4582711.89 430630.24 4582707.73 430628.39 4582709.65 430627.33 4582710.75 430624.55 4582713.64 430622.33 4582715.95 430621.77 4582716.54 430620.26 4582718.1 430619.27 4582719.13 430616.88 4582721.61 430614.63 4582723.95 430612.29 4582726.38 430610.93 4582727.79 430610.76 4582727.97 430600.13 4582739.01 430598.99 4582740.2</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0629618DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>18</cp:label>
      <cp:nationalCadastralReference>0629618DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0629618DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430631.42 4582711.44</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0629619DF3802H">
      <cp:areaValue uom="m2">546</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0629619DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0629619DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="34">430590.01 4582731.96 430598.99 4582740.2 430600.13 4582739.01 430610.76 4582727.97 430610.93 4582727.79 430612.29 4582726.38 430614.63 4582723.95 430616.88 4582721.61 430619.27 4582719.13 430620.26 4582718.1 430621.77 4582716.54 430622.33 4582715.95 430624.55 4582713.64 430627.33 4582710.75 430628.39 4582709.65 430630.24 4582707.73 430621.71 4582699.37 430620.37 4582700.74 430619.86 4582701.27 430618.87 4582702.28 430618.51 4582702.65 430616.17 4582705.06 430615.27 4582705.98 430613.2 4582708.11 430610.77 4582710.62 430610.25 4582711.15 430608.36 4582713.1 430605.99 4582715.53 430605.89 4582715.64 430602.42 4582719.2 430602.07 4582719.56 430591.71 4582730.21 430591.16 4582730.78 430590.01 4582731.96</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0629619DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>19</cp:label>
      <cp:nationalCadastralReference>0629619DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0629619DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430607.81 4582722.3</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0629620DF3802H">
      <cp:areaValue uom="m2">789</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0629620DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0629620DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="35">430586.68 4582728.66 430590.01 4582731.96 430591.16 4582730.78 430591.71 4582730.21 430602.07 4582719.56 430602.42 4582719.2 430605.89 4582715.64 430605.99 4582715.53 430608.36 4582713.1 430610.25 4582711.15 430610.77 4582710.62 430613.2 4582708.11 430615.27 4582705.98 430616.17 4582705.06 430618.51 4582702.65 430618.87 4582702.28 430619.86 4582701.27 430620.37 4582700.74 430621.71 4582699.37 430609.27 4582687.2 430607.9 4582688.61 430607.53 4582688.99 430606.41 4582690.15 430606.05 4582690.52 430602.87 4582693.8 430602.57 4582694.11 430597.88 4582698.95 430597.26 4582699.6 430596.39 4582700.5 430593.3 4582703.69 430589.94 4582707.15 430579.27 4582718.16 430577.57 4582719.91 430578.48 4582720.79 430586.68 4582728.66</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0629620DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>20</cp:label>
      <cp:nationalCadastralReference>0629620DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0629620DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430597 4582712.34</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0629621DF3802H">
      <cp:areaValue uom="m2">617</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0629621DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0629621DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="24">430571.09 4582689.99 430573.1 4582691.81 430573.38 4582692.06 430574.47 4582693.05 430575.61 4582694.09 430581.35 4582699.3 430585.75 4582703.31 430587.67 4582705.05 430588.92 4582706.19 430589.94 4582707.15 430593.3 4582703.69 430596.39 4582700.5 430597.26 4582699.6 430597.88 4582698.95 430602.57 4582694.11 430602.87 4582693.8 430606.05 4582690.52 430606.41 4582690.15 430607.53 4582688.99 430607.9 4582688.61 430609.27 4582687.2 430601.19 4582679.3 430581.04 4582679.72 430571.09 4582689.99</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0629621DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>21</cp:label>
      <cp:nationalCadastralReference>0629621DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0629621DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430590.77 4582687.98</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0629622DF3802H">
      <cp:areaValue uom="m2">452</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0629622DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0629622DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="22">430589.94 4582707.15 430588.92 4582706.19 430587.67 4582705.05 430585.75 4582703.31 430581.35 4582699.3 430575.61 4582694.09 430574.47 4582693.05 430573.38 4582692.06 430573.1 4582691.81 430571.09 4582689.99 430558.78 4582702.68 430561.17 4582704.88 430563.37 4582706.9 430565.27 4582708.63 430568.93 4582711.99 430571.99 4582714.8 430575.34 4582717.86 430576.58 4582719.01 430576.99 4582719.38 430577.57 4582719.91 430579.27 4582718.16 430589.94 4582707.15</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0629622DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>22</cp:label>
      <cp:nationalCadastralReference>0629622DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0629622DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430576.41 4582706.8</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0629623DF3802H">
      <cp:areaValue uom="m2">466</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0629623DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0629623DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="18">430577.94 4582737.67 430586.68 4582728.66 430578.48 4582720.79 430577.57 4582719.91 430576.99 4582719.38 430576.58 4582719.01 430575.34 4582717.86 430571.99 4582714.8 430568.93 4582711.99 430565.27 4582708.63 430563.37 4582706.9 430561.17 4582704.88 430558.78 4582702.68 430550.62 4582711.06 430563.44 4582723.55 430568.22 4582728.2 430569.71 4582729.65 430577.94 4582737.67</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0629623DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>23</cp:label>
      <cp:nationalCadastralReference>0629623DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0629623DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430571.14 4582722.33</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0629624DF3802H">
      <cp:areaValue uom="m2">448</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0629624DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0629624DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="11">430569.69 4582746.16 430577.94 4582737.67 430569.71 4582729.65 430568.22 4582728.2 430563.44 4582723.55 430550.62 4582711.06 430542.51 4582719.39 430552.23 4582728.97 430555.15 4582731.84 430561.42 4582738.02 430569.69 4582746.16</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0629624DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>24</cp:label>
      <cp:nationalCadastralReference>0629624DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0629624DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430562.47 4582730.78</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0629625DF3802H">
      <cp:areaValue uom="m2">514</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0629625DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0629625DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="19">430557.51 4582755.28 430559.07 4582757.13 430569.69 4582746.16 430561.42 4582738.02 430555.15 4582731.84 430552.23 4582728.97 430542.51 4582719.39 430534.39 4582727.73 430536.3 4582730.01 430537.82 4582731.82 430539.55 4582733.88 430540.02 4582734.44 430543.22 4582738.25 430543.38 4582738.44 430545.85 4582741.39 430546.76 4582742.47 430549.51 4582745.75 430551.5 4582748.12 430557.51 4582755.28</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0629625DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>25</cp:label>
      <cp:nationalCadastralReference>0629625DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0629625DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430554.61 4582740.59</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0629626DF3802H">
      <cp:areaValue uom="m2">1530</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0629626DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0629626DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="21">430583.65 4582786.38 430587.92 4582781.92 430588.77 4582781.03 430598.59 4582770.76 430599.38 4582769.94 430600.23 4582769.06 430608.32 4582760.59 430609.12 4582759.76 430614.4 4582754.24 430613.78 4582753.6 430603.22 4582744.09 430598.99 4582740.2 430590.01 4582731.96 430586.68 4582728.66 430577.94 4582737.67 430569.69 4582746.16 430559.07 4582757.13 430563.5 4582762.4 430567.36 4582767 430575.54 4582776.74 430583.65 4582786.38</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                <gml:interior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="34">430597.07 4582740.93 430598.05 4582741.14 430598.87 4582741.53 430599.73 4582742.22 430600.3 4582742.95 430600.67 4582743.71 430600.89 4582744.61 430600.92 4582745.38 430600.82 4582746.13 430600.62 4582746.76 430600.29 4582747.42 430601.17 4582748.31 430599.96 4582749.53 430599.16 4582748.65 430598.75 4582748.91 430598.23 4582749.15 430597.55 4582749.36 430596.67 4582749.46 430595.87 4582749.39 430595.06 4582749.15 430594.3 4582748.75 430593.63 4582748.21 430593.12 4582747.58 430592.77 4582746.97 430592.5 4582746.16 430592.39 4582745.23 430592.43 4582744.58 430592.75 4582743.46 430593.21 4582742.67 430593.79 4582742.03 430594.5 4582741.5 430595.28 4582741.14 430596.26 4582740.93 430597.07 4582740.93</gml:posList>
                    </gml:LinearRing>
                </gml:interior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0629626DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>26</cp:label>
      <cp:nationalCadastralReference>0629626DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0629626DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430585.12 4582761.08</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0629627DF3802H">
      <cp:areaValue uom="m2">59</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0629627DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0629627DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="34">430597.07 4582740.93 430596.26 4582740.93 430595.28 4582741.14 430594.5 4582741.5 430593.79 4582742.03 430593.21 4582742.67 430592.75 4582743.46 430592.43 4582744.58 430592.39 4582745.23 430592.5 4582746.16 430592.77 4582746.97 430593.12 4582747.58 430593.63 4582748.21 430594.3 4582748.75 430595.06 4582749.15 430595.87 4582749.39 430596.67 4582749.46 430597.55 4582749.36 430598.23 4582749.15 430598.75 4582748.91 430599.16 4582748.65 430599.96 4582749.53 430601.17 4582748.31 430600.29 4582747.42 430600.62 4582746.76 430600.82 4582746.13 430600.92 4582745.38 430600.89 4582744.61 430600.67 4582743.71 430600.3 4582742.95 430599.73 4582742.22 430598.87 4582741.53 430598.05 4582741.14 430597.07 4582740.93</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0629627DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>27</cp:label>
      <cp:nationalCadastralReference>0629627DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0629627DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430596.66 4582745.76</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0728501DF3802H">
      <cp:areaValue uom="m2">504</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0728501DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0728501DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="27">430672.82 4582721.41 430674.31 4582722.86 430675.63 4582724.09 430677.19 4582724.74 430678.85 4582725.01 430694.79 4582724.78 430696.01 4582724.43 430697 4582723.9 430698.03 4582722.91 430707.31 4582713.42 430704.41 4582710.59 430702.36 4582708.59 430704.43 4582706.52 430699.62 4582701.87 430697.07 4582699.4 430696.3 4582698.65 430695.75 4582698.11 430693.1 4582700.81 430692.4 4582701.53 430691.62 4582702.31 430686.45 4582707.54 430685.84 4582708.16 430684.91 4582709.1 430682.68 4582711.35 430681.71 4582712.34 430679.81 4582714.27 430672.82 4582721.41</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0728501DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>01</cp:label>
      <cp:nationalCadastralReference>0728501DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0728501DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430690.6 4582707.38</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0728502DF3802H">
      <cp:areaValue uom="m2">274</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0728502DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0728502DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="17">430704.41 4582710.59 430707.31 4582713.42 430717.58 4582702.86 430714.75 4582700.07 430713.01 4582698.35 430711.3 4582696.67 430708.75 4582694.16 430702.32 4582687.8 430700.61 4582689.59 430694.04 4582696.45 430695.75 4582698.11 430696.3 4582698.65 430697.07 4582699.4 430699.62 4582701.87 430704.43 4582706.52 430702.36 4582708.59 430704.41 4582710.59</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0728502DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>02</cp:label>
      <cp:nationalCadastralReference>0728502DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0728502DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430699.25 4582696.42</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0728503DF3802H">
      <cp:areaValue uom="m2">1789</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0728503DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0728503DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="30">430717.58 4582702.86 430718.23 4582702.19 430734.28 4582685.68 430735.08 4582684.85 430722.34 4582672.29 430721.63 4582671.59 430719.17 4582669.17 430717.1 4582667.13 430714.87 4582664.94 430712.31 4582662.41 430698.39 4582648.71 430687.51 4582637.99 430684.25 4582634.78 430677.08 4582642.16 430675.22 4582644.07 430674.01 4582645.31 430672.88 4582646.47 430670.71 4582648.7 430666.78 4582652.73 430669.13 4582655.04 430676.16 4582661.97 430685.42 4582671.1 430694.71 4582680.28 430699.71 4582685.22 430702.32 4582687.8 430708.75 4582694.16 430711.3 4582696.67 430713.01 4582698.35 430714.75 4582700.07 430717.58 4582702.86</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0728503DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>03</cp:label>
      <cp:nationalCadastralReference>0728503DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0728503DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430719.66 4582679.57</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0728506DF3802H">
      <cp:areaValue uom="m2">866</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0728506DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0728506DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="19">430712.31 4582662.41 430723.66 4582650.64 430726.27 4582647.92 430730.38 4582643.64 430734.46 4582639.39 430736.6 4582637.15 430737.7 4582636.01 430741.54 4582632.02 430743.09 4582630.42 430729.17 4582616.78 430727.67 4582618.33 430727.24 4582618.78 430721.2 4582625.05 430715.03 4582631.45 430713.09 4582633.47 430709.69 4582637 430707.58 4582639.18 430698.39 4582648.71 430712.31 4582662.41</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0728506DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>06</cp:label>
      <cp:nationalCadastralReference>0728506DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0728506DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430709.22 4582651.55</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0728507DF3802H">
      <cp:areaValue uom="m2">876</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0728507DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0728507DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="27">430707.58 4582639.18 430709.69 4582637 430713.09 4582633.47 430715.03 4582631.45 430721.2 4582625.05 430727.24 4582618.78 430727.67 4582618.33 430729.17 4582616.78 430715.06 4582603.04 430713.16 4582605 430712.87 4582605.3 430710.74 4582607.49 430708.31 4582610 430707.06 4582611.28 430700.97 4582617.56 430699.97 4582618.59 430698.92 4582619.66 430695.93 4582622.75 430694.71 4582624 430693.71 4582625.03 430693.37 4582625.38 430687.13 4582631.81 430685.57 4582633.42 430684.25 4582634.78 430687.51 4582637.99 430698.39 4582648.71 430707.58 4582639.18</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0728507DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>07</cp:label>
      <cp:nationalCadastralReference>0728507DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0728507DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430697.72 4582640.29</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0728508DF3802H">
      <cp:areaValue uom="m2">365</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0728508DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0728508DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="28">430694.71 4582624 430695.93 4582622.75 430698.92 4582619.66 430699.97 4582618.59 430700.97 4582617.56 430707.06 4582611.28 430708.31 4582610 430710.74 4582607.49 430712.87 4582605.3 430713.16 4582605 430715.06 4582603.04 430712.8 4582600.83 430708.52 4582596.65 430706.15 4582594.34 430705.26 4582595.25 430703.92 4582596.62 430703.17 4582597.39 430701.7 4582598.9 430701.28 4582599.33 430700.04 4582600.61 430698.6 4582602.08 430694.59 4582606.21 430694.15 4582606.67 430692.39 4582608.47 430691.24 4582609.66 430686.83 4582614.18 430685.75 4582615.29 430694.71 4582624</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0728508DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>08</cp:label>
      <cp:nationalCadastralReference>0728508DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0728508DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430697.27 4582610.95</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0728509DF3802H">
      <cp:areaValue uom="m2">766</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0728509DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0728509DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="34">430686.83 4582614.18 430691.24 4582609.66 430692.39 4582608.47 430694.15 4582606.67 430694.59 4582606.21 430698.6 4582602.08 430700.04 4582600.61 430701.28 4582599.33 430701.7 4582598.9 430703.17 4582597.39 430703.92 4582596.62 430705.26 4582595.25 430706.15 4582594.34 430696.42 4582584.82 430695.31 4582584.09 430693.92 4582583.68 430692.74 4582583.53 430677.53 4582583.58 430676.27 4582583.8 430674.81 4582584.31 430674.01 4582584.93 430664.56 4582594.55 430665.53 4582595.49 430667.91 4582597.82 430669.46 4582599.34 430670.7 4582600.55 430671.2 4582601.03 430676.86 4582606.59 430677.87 4582607.58 430678.74 4582608.44 430679.62 4582609.3 430682.68 4582612.29 430685.75 4582615.29 430686.83 4582614.18</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0728509DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>09</cp:label>
      <cp:nationalCadastralReference>0728509DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0728509DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430674.6 4582601.07</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0728510DF3802H">
      <cp:areaValue uom="m2">554</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0728510DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0728510DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="29">430684.91 4582632.78 430685.57 4582633.42 430687.13 4582631.81 430693.37 4582625.38 430693.71 4582625.03 430694.71 4582624 430685.75 4582615.29 430682.68 4582612.29 430679.62 4582609.3 430678.74 4582608.44 430677.87 4582607.58 430676.86 4582606.59 430671.2 4582601.03 430670.7 4582600.55 430669.46 4582599.34 430667.91 4582597.82 430665.53 4582595.49 430664.56 4582594.55 430655.33 4582603.95 430660.09 4582608.59 430662.95 4582611.38 430663.14 4582611.56 430665.51 4582613.88 430668.7 4582616.99 430670.45 4582618.69 430673.49 4582621.66 430676.39 4582624.49 430678.05 4582626.1 430684.91 4582632.78</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0728510DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>10</cp:label>
      <cp:nationalCadastralReference>0728510DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0728510DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430673.2 4582612.73</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0728511DF3802H">
      <cp:areaValue uom="m2">624</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0728511DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0728511DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="28">430674.57 4582643.44 430675.22 4582644.07 430677.08 4582642.16 430684.25 4582634.78 430685.57 4582633.42 430684.91 4582632.78 430678.05 4582626.1 430676.39 4582624.49 430673.49 4582621.66 430670.45 4582618.69 430668.7 4582616.99 430665.51 4582613.88 430663.14 4582611.56 430662.95 4582611.38 430660.09 4582608.59 430655.33 4582603.95 430645.06 4582614.48 430650.03 4582619.36 430651.84 4582621.14 430652.9 4582622.18 430655.25 4582624.48 430658.48 4582627.65 430660.39 4582629.53 430663.27 4582632.36 430664 4582633.06 430666.1 4582635.13 430667.71 4582636.71 430674.57 4582643.44</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0728511DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>11</cp:label>
      <cp:nationalCadastralReference>0728511DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0728511DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430667.87 4582625.27</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0728512DF3802H">
      <cp:areaValue uom="m2">622</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0728512DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0728512DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="33">430665.05 4582654.51 430666.78 4582652.73 430670.71 4582648.7 430672.88 4582646.47 430674.01 4582645.31 430675.22 4582644.07 430674.57 4582643.44 430667.71 4582636.71 430666.1 4582635.13 430664 4582633.06 430663.27 4582632.36 430660.39 4582629.53 430658.48 4582627.65 430655.25 4582624.48 430652.9 4582622.18 430651.84 4582621.14 430650.03 4582619.36 430645.06 4582614.48 430634.67 4582625.16 430636.44 4582626.84 430639.53 4582629.83 430640.01 4582630.29 430642.41 4582632.61 430643.86 4582634.02 430646.3 4582636.38 430648.22 4582638.23 430650.09 4582640.04 430651.68 4582641.58 430653.04 4582642.89 430653.71 4582643.54 430654.43 4582644.23 430655.25 4582645.03 430665.05 4582654.51</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0728512DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>12</cp:label>
      <cp:nationalCadastralReference>0728512DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0728512DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430653.06 4582632.98</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0728513DF3802H">
      <cp:areaValue uom="m2">552</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0728513DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0728513DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="32">430657.92 4582661.81 430660 4582659.67 430665.05 4582654.51 430655.25 4582645.03 430654.43 4582644.23 430653.71 4582643.54 430653.04 4582642.89 430651.68 4582641.58 430650.09 4582640.04 430648.22 4582638.23 430646.3 4582636.38 430643.86 4582634.02 430642.41 4582632.61 430640.01 4582630.29 430639.53 4582629.83 430636.44 4582626.84 430634.67 4582625.16 430625.55 4582634.46 430627.39 4582636.24 430630.96 4582639.7 430632.55 4582641.25 430634.85 4582643.47 430639.14 4582647.62 430640.98 4582649.4 430642.54 4582650.9 430643.85 4582652.18 430644.98 4582653.26 430645.29 4582653.57 430646.07 4582654.32 430646.72 4582654.95 430655.91 4582663.85 430657.92 4582661.81</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0728513DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>13</cp:label>
      <cp:nationalCadastralReference>0728513DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0728513DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430641.95 4582642.76</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0728514DF3802H">
      <cp:areaValue uom="m2">766</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0728514DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0728514DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="29">430626.11 4582675.74 430629.33 4582672.47 430631.19 4582670.58 430632.59 4582669.15 430634.38 4582667.34 430636.69 4582665.02 430637.3 4582664.4 430637.96 4582663.73 430639.37 4582662.32 430642.3 4582659.38 430644.52 4582657.16 430646.72 4582654.95 430646.07 4582654.32 430645.29 4582653.57 430644.98 4582653.26 430643.85 4582652.18 430642.54 4582650.9 430640.98 4582649.4 430639.14 4582647.62 430634.85 4582643.47 430632.55 4582641.25 430630.96 4582639.7 430627.39 4582636.24 430625.55 4582634.46 430615.82 4582644.32 430614.69 4582646.86 430614.66 4582663.45 430615.8 4582665.71 430626.11 4582675.74</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0728514DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>14</cp:label>
      <cp:nationalCadastralReference>0728514DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0728514DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430632.49 4582654.18</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0728515DF3802H">
      <cp:areaValue uom="m2">378</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0728515DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0728515DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="29">430636.91 4582683.26 430638.5 4582681.62 430639.53 4582680.57 430640.43 4582679.65 430641.79 4582678.26 430643.49 4582676.52 430645.91 4582674.04 430646.76 4582673.18 430647.21 4582672.71 430651.42 4582668.42 430653.47 4582666.34 430653.66 4582666.14 430655.91 4582663.85 430646.72 4582654.95 430644.52 4582657.16 430642.3 4582659.38 430639.37 4582662.32 430637.96 4582663.73 430637.3 4582664.4 430636.69 4582665.02 430634.38 4582667.34 430632.59 4582669.15 430631.19 4582670.58 430629.33 4582672.47 430626.11 4582675.74 430628.14 4582677.72 430633.2 4582682.66 430635.4 4582684.81 430636.91 4582683.26</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0728515DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>15</cp:label>
      <cp:nationalCadastralReference>0728515DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0728515DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430640.98 4582665.55</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0728516DF3802H">
      <cp:areaValue uom="m2">590</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0728516DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0728516DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="33">430644.8 4582694.01 430646.23 4582692.54 430648.88 4582689.83 430652.97 4582685.65 430656.2 4582682.35 430659.14 4582679.36 430662.86 4582675.56 430667.26 4582671.07 430669.38 4582668.91 430674.51 4582663.67 430676.16 4582661.97 430669.13 4582655.04 430666.78 4582652.73 430665.05 4582654.51 430660 4582659.67 430657.92 4582661.81 430655.91 4582663.85 430653.66 4582666.14 430653.47 4582666.34 430651.42 4582668.42 430647.21 4582672.71 430646.76 4582673.18 430645.91 4582674.04 430643.49 4582676.52 430641.79 4582678.26 430640.43 4582679.65 430639.53 4582680.57 430638.5 4582681.62 430636.91 4582683.26 430635.4 4582684.81 430637.69 4582687.05 430642.53 4582691.78 430644.8 4582694.01</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0728516DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>16</cp:label>
      <cp:nationalCadastralReference>0728516DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0728516DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430662.22 4582664.53</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0728517DF3802H">
      <cp:areaValue uom="m2">585</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0728517DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0728517DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="19">430654.15 4582703.2 430662.33 4582694.8 430663.99 4582693.09 430665.55 4582691.49 430666.14 4582690.88 430673.66 4582683.17 430685.42 4582671.1 430676.16 4582661.97 430674.51 4582663.67 430669.38 4582668.91 430667.26 4582671.07 430662.86 4582675.56 430659.14 4582679.36 430656.2 4582682.35 430652.97 4582685.65 430648.88 4582689.83 430646.23 4582692.54 430644.8 4582694.01 430654.15 4582703.2</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0728517DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>17</cp:label>
      <cp:nationalCadastralReference>0728517DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0728517DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430665.69 4582677.58</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0728518DF3802H">
      <cp:areaValue uom="m2">584</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0728518DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0728518DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="13">430654.15 4582703.2 430663.48 4582712.31 430673.3 4582702.23 430675.48 4582699.99 430683 4582692.3 430694.71 4582680.28 430685.42 4582671.1 430673.66 4582683.17 430666.14 4582690.88 430665.55 4582691.49 430663.99 4582693.09 430662.33 4582694.8 430654.15 4582703.2</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0728518DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>18</cp:label>
      <cp:nationalCadastralReference>0728518DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0728518DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430672.76 4582689.76</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0728519DF3802H">
      <cp:areaValue uom="m2">558</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0728519DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0728519DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="21">430672.82 4582721.41 430679.81 4582714.27 430681.71 4582712.34 430682.68 4582711.35 430684.91 4582709.1 430685.84 4582708.16 430686.45 4582707.54 430691.62 4582702.31 430692.4 4582701.53 430693.1 4582700.81 430695.75 4582698.11 430694.04 4582696.45 430700.61 4582689.59 430702.32 4582687.8 430699.71 4582685.22 430694.71 4582680.28 430683 4582692.3 430675.48 4582699.99 430673.3 4582702.23 430663.48 4582712.31 430672.82 4582721.41</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0728519DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>19</cp:label>
      <cp:nationalCadastralReference>0728519DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0728519DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430682.72 4582698.99</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0826205DF3802F">
      <cp:areaValue uom="m2">429</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0826205DF3802F" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0826205DF3802F.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="24">430673.23 4582492.15 430683.7 4582502.4 430689.47 4582496.55 430690.4 4582495.6 430692.78 4582493.19 430693.12 4582492.85 430695.79 4582490.15 430700.58 4582485.29 430702.1 4582483.75 430703.26 4582482.56 430704.24 4582481.57 430702.93 4582480.28 430693.76 4582471.28 430691.89 4582473.18 430691.63 4582473.46 430691.47 4582473.62 430690.51 4582474.59 430690.13 4582474.98 430685.22 4582479.96 430682.62 4582482.61 430679.7 4582485.57 430679.01 4582486.28 430677.2 4582488.12 430673.23 4582492.15</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0826205DF3802F</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>05</cp:label>
      <cp:nationalCadastralReference>0826205DF3802F</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0826205DF3802F" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430686.86 4582488.76</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0826206DF3802F">
      <cp:areaValue uom="m2">340</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0826206DF3802F" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0826206DF3802F.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="23">430683.7 4582502.4 430692.01 4582510.53 430694.24 4582508.27 430697.3 4582505.17 430698.71 4582503.74 430700.4 4582502.04 430701.45 4582500.98 430705.09 4582497.3 430708.09 4582494.27 430711.62 4582490.68 430712.54 4582489.74 430711.75 4582488.96 430709.77 4582487.01 430704.24 4582481.57 430703.26 4582482.56 430702.1 4582483.75 430700.58 4582485.29 430695.79 4582490.15 430693.12 4582492.85 430692.78 4582493.19 430690.4 4582495.6 430689.47 4582496.55 430683.7 4582502.4</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0826206DF3802F</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>06</cp:label>
      <cp:nationalCadastralReference>0826206DF3802F</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0826206DF3802F" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430696.38 4582497.84</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0826207DF3802F">
      <cp:areaValue uom="m2">455</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0826207DF3802F" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0826207DF3802F.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="18">430692.01 4582510.53 430695.6 4582514.05 430715.37 4582513.83 430726 4582503 430723.82 4582500.87 430719.05 4582496.17 430718.05 4582495.18 430716.03 4582493.18 430712.54 4582489.74 430711.62 4582490.68 430708.09 4582494.27 430705.09 4582497.3 430701.45 4582500.98 430700.4 4582502.04 430698.71 4582503.74 430697.3 4582505.17 430694.24 4582508.27 430692.01 4582510.53</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0826207DF3802F</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>07</cp:label>
      <cp:nationalCadastralReference>0826207DF3802F</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0826207DF3802F" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430712.32 4582503.4</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
  <member>
    <cp:CadastralParcel gml:id="ES.SDGC.CP.0827201DF3802H">
      <cp:areaValue uom="m2">100</cp:areaValue>
      <cp:beginLifespanVersion>2001-10-29T00:00:00</cp:beginLifespanVersion>
      <cp:endLifespanVersion xsi:nil="true" nilReason="http://inspire.ec.europa.eu/codelist/VoidReasonValue/Unpopulated"></cp:endLifespanVersion>
      <cp:geometry>
        <gml:MultiSurface gml:id="MultiSurface_ES.SDGC.CP.0827201DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
          <gml:surfaceMember>
            <gml:Surface gml:id="Surface_ES.SDGC.CP.0827201DF3802H.1" srsName="http://www.opengis.net/def/crs/EPSG/0/25831">
              <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="11">430700.56 4582551.45 430699.7 4582552 430698.53 4582553.06 430697.77 4582553.89 430697.31 4582554.63 430712.97 4582569.96 430713.83 4582569.39 430714.76 4582568.51 430715.72 4582567.31 430716.07 4582566.74 430700.56 4582551.45</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </cp:geometry>
      <cp:inspireId>
        <Identifier xmlns="http://inspire.ec.europa.eu/schemas/base/3.3">
          <localId>0827201DF3802H</localId>
          <namespace>ES.SDGC.CP</namespace>
        </Identifier>
      </cp:inspireId>
      <cp:label>01</cp:label>
      <cp:nationalCadastralReference>0827201DF3802H</cp:nationalCadastralReference>
      <cp:referencePoint>
        <gml:Point gml:id="ReferencePoint_ES.SDGC.CP.0827201DF3802H" srsName="http://www.opengis.net/def/crs/EPSG/0/25831"> 
          <gml:pos>430704.89 4582558.22</gml:pos>
        </gml:Point>
      </cp:referencePoint>
    </cp:CadastralParcel>
  </member>
</FeatureCollection>